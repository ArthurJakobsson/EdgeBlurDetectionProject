#Blur for fed in photograph

import cv2

import numpy as np

import matplotlib.pyplot as plt

#sets a scale for displaying images
SCALE = 0.5
